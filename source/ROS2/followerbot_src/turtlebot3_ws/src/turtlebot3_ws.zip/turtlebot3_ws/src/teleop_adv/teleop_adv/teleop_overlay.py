#!/usr/bin/env python3
"""
Keyboard-based speed scaler for TurtleBot3 patrol server.

W/X : increase/decrease linear speed multiplier
A/D : increase/decrease angular speed multiplier
S or SPACE : reset both multipliers to 1.0
"""

from __future__ import annotations

import os
import select
import sys
import threading
from typing import Optional

if os.name == 'nt':
    import msvcrt  # type: ignore
else:
    import termios
    import tty

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.parameter_client import AsyncParameterClient


class TeleopSpeedScaler(Node):
    """Adjust patrol server speed parameters using WASDX input."""

    def __init__(self) -> None:
        # 기본 네임스페이스를 /tb3_2 로 하되, --ros-args -r __ns:=... 로 변경 가능
        super().__init__('teleop_overlay', namespace='tb3_2')

        self.declare_parameter('server_node_name', 'turtlebot3_patrol_server')
        self.declare_parameter('linear_scale_step', 0.1)
        self.declare_parameter('angular_scale_step', 0.1)
        self.declare_parameter('min_scale', 0.2)
        self.declare_parameter('max_scale', 2.5)

        self._server_node_name = str(self.get_parameter('server_node_name').value)
        self._linear_scale_step = float(self.get_parameter('linear_scale_step').value)
        self._angular_scale_step = float(self.get_parameter('angular_scale_step').value)
        self._min_scale = float(self.get_parameter('min_scale').value)
        self._max_scale = float(self.get_parameter('max_scale').value)

        self._param_client = AsyncParameterClient(self, self._server_node_name)
        self._base_linear: Optional[float] = None
        self._base_angular: Optional[float] = None
        self._linear_scale = 1.0
        self._angular_scale = 1.0

        self._stop_evt = threading.Event()
        self._keyboard_thread: Optional[threading.Thread] = None
        self._term_settings = None

        self._connect_and_fetch_defaults()
        self._start_keyboard_listener()

        self.get_logger().info(
            "teleop_overlay ready. Keys: w/x (linear +/-), a/d (angular +/-), s or space (reset)."
        )
        self._log_scale()

    # --------------------------------------------------------------------- init helpers
    def _connect_and_fetch_defaults(self) -> None:
        self.get_logger().info(f"Waiting for parameter server '{self._server_full_name()}' ...")
        while rclpy.ok() and not self._param_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('  still waiting...')

        if not rclpy.ok():
            raise RuntimeError('ROS shutdown before parameter service became available.')

        params_future = self._param_client.get_parameters(
            ['max_linear_speed', 'max_angular_speed']
        )
        rclpy.spin_until_future_complete(self, params_future)
        if params_future.result() is None:
            raise RuntimeError('Failed to retrieve patrol server parameters.')

        values = {p.name: p.value for p in params_future.result()}
        self._base_linear = float(values.get('max_linear_speed', 0.07))
        self._base_angular = float(values.get('max_angular_speed', 0.4))
        self.get_logger().info(
            f"Base speeds loaded: linear={self._base_linear:.3f}, angular={self._base_angular:.3f}"
        )

    def _start_keyboard_listener(self) -> None:
        if os.name == 'nt':
            self._keyboard_thread = threading.Thread(
                target=self._keyboard_loop_windows, daemon=True
            )
        else:
            self._term_settings = termios.tcgetattr(sys.stdin)
            self._keyboard_thread = threading.Thread(
                target=self._keyboard_loop_posix, daemon=True
            )
        self._keyboard_thread.start()

    # --------------------------------------------------------------------- keyboard handling
    def _keyboard_loop_posix(self) -> None:
        assert self._term_settings is not None
        try:
            while not self._stop_evt.is_set():
                key = self._get_key_posix()
                if key == '':
                    continue
                if key == '\x03':  # Ctrl+C
                    raise KeyboardInterrupt
                self._handle_key(key)
        except KeyboardInterrupt:
            self.get_logger().info('Keyboard interrupt detected, shutting down.')
            rclpy.shutdown()
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self._term_settings)
            self._stop_evt.set()

    def _keyboard_loop_windows(self) -> None:
        try:
            while not self._stop_evt.is_set():
                if msvcrt.kbhit():
                    key = msvcrt.getch().decode('utf-8').lower()
                    if key == '\x03':
                        raise KeyboardInterrupt
                    self._handle_key(key)
        except KeyboardInterrupt:
            self.get_logger().info('Keyboard interrupt detected, shutting down.')
            rclpy.shutdown()
        finally:
            self._stop_evt.set()

    def _get_key_posix(self) -> str:
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self._term_settings)
        return key.lower()

    # --------------------------------------------------------------------- key logic
    def _handle_key(self, key: str) -> None:
        updated = False
        if key == 'w':
            self._linear_scale = self._clamp(self._linear_scale + self._linear_step(), self._min_scale, self._max_scale)
            updated = True
        elif key == 'x':
            self._linear_scale = self._clamp(self._linear_scale - self._linear_step(), self._min_scale, self._max_scale)
            updated = True
        elif key == 'a':
            self._angular_scale = self._clamp(self._angular_scale + self._angular_step(), self._min_scale, self._max_scale)
            updated = True
        elif key == 'd':
            self._angular_scale = self._clamp(self._angular_scale - self._angular_step(), self._min_scale, self._max_scale)
            updated = True
        elif key in ('s', ' '):
            self._linear_scale = 1.0
            self._angular_scale = 1.0
            updated = True

        if updated:
            self._apply_scales()
            self._log_scale()

    def _linear_step(self) -> float:
        return self._linear_scale_step

    def _angular_step(self) -> float:
        return self._angular_scale_step

    # --------------------------------------------------------------------- parameter update
    def _apply_scales(self) -> None:
        if self._base_linear is None or self._base_angular is None:
            return

        new_linear = self._base_linear * self._linear_scale
        new_angular = self._base_angular * self._angular_scale

        params = [
            Parameter('max_linear_speed', Parameter.Type.DOUBLE, new_linear),
            Parameter('max_angular_speed', Parameter.Type.DOUBLE, new_angular),
        ]
        future = self._param_client.set_parameters(params)
        future.add_done_callback(self._on_params_set)

    def _log_scale(self) -> None:
        if self._base_linear is None or self._base_angular is None:
            return
        self.get_logger().info(
            f"[Speed scale] linear={self._linear_scale:.2f} (max {self._base_linear*self._linear_scale:.3f} m/s), "
            f"angular={self._angular_scale:.2f} (max {self._base_angular*self._angular_scale:.3f} rad/s)"
        )

    # --------------------------------------------------------------------- helpers
    def _server_full_name(self) -> str:
        node_ns = self.get_namespace().rstrip('/')
        if not node_ns:
            return self._server_node_name
        if self._server_node_name.startswith('/'):
            return self._server_node_name
        return f'/{node_ns}/{self._server_node_name}'

    @staticmethod
    def _clamp(value: float, low: float, high: float) -> float:
        return max(low, min(value, high))

    def _on_params_set(self, future) -> None:
        try:
            result = future.result()
        except Exception as exc:  # noqa: BLE001
            self.get_logger().warn(f'Failed to update patrol parameters: {exc}')
            return
        if not all(r.successful for r in result):
            self.get_logger().warn('One or more parameter updates were rejected.')

    def destroy_node(self) -> bool:
        self._stop_evt.set()
        if self._keyboard_thread is not None:
            self._keyboard_thread.join(timeout=1.0)
        if (
            os.name != 'nt'
            and self._term_settings is not None
        ):
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self._term_settings)
            except Exception:  # noqa: BLE001
                pass
        return super().destroy_node()


def main(args: list[str] | None = None) -> None:
    rclpy.init(args=args)
    node = TeleopSpeedScaler()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
